<?php
if (!defined('EVA_API')) { exit; }

// ID do Meta Pixel (o mesmo que está em assets/js/main.js -> CONFIG.metaPixelId)
define('META_PIXEL_ID', '1097759599611282');

// Token de acesso da Conversions API (gerado em Eventos Manager > Configurações > Conversions API)
define('META_ACCESS_TOKEN', 'EAAJfrI8NqZB8BSojMS5VFEhZAmIDJY0IRYlazVxfzhcuuwE3EsPuUvKhGvBML4BVZCspSYZCS7Ij6twEzV4ItLYL6T7aLeRspRkMNqZAVfraKXnQMBZAnUfVeZBOAbS1UF0fwowwMvO9jVHkvmKzpateixq0vfGTmpLEg3MVm7AVO9TgQ0eiitX71Id0sFJNp5nXAZDZD');
